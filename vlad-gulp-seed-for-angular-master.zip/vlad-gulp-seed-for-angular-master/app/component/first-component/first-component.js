angular.module('component.first-component', [
]).directive('firstComponent', function () {
    return {
        templateUrl: 'app/component/first-component/first-component.html'
    };
});