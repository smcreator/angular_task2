angular.module('test-application').directive('testApplication', function () { //jshint ignore: line
    return {
        templateUrl: 'app/test-application.html'
    };
});
